﻿ | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | 10.43MB  | 83.02          | 1.56        | 0.37        | 81.05         | 0           | 
 | time_providers_shared.dll | Pass   | 12KB     | 93.96          | 0.7         | 0.4         | 91.99         | 0           | 
